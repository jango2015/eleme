## Aspose.OCR for .NET Examples

This directory contains C# and VB.NET examples for [Aspose.OCR for .NET](http://www.aspose.com/.net/ocr-component.aspx).

## How to use the examples?

Examples are provided as Visual Studio solutions. Download the code and use your favourite version of Visual Studio to run the examples.
See our [documentation](http://www.aspose.com/docs/display/ocrnet/How+to+use+the+Examples) for more details.
