/**
 * 
 *  created by jango cheng 2016/11/01 
 * 
 */

var express = require('express');
var router = express.Router();
var moment =require("moment");

var models = require('./../models/shopmodel.js');
var model = models.shopmodel;

router.get('/',function(req,res,next){
    model.count(function(error,doc){
        if(doc >0){
            model.find(function(error,rep){
                if(error){
                    res.send(error);
                }
                else{
                    res.render('shop/index',{title:"this is the shop lists ",list:rep});
                }
            })
        }
    })
});

router.get('/edit',function(req,res,next){
    console.log(req);
    res.render('shop/edit',{err_msg:''})
});

router.post('/edit',function(req,res,next){
    // console.log(req.body);
    // for(var key in req.body){
    //     console.log("key :"+key+"   value:"+req.body[key])
    // }
    if(!validate(req.body)){
        var err_msg = "some field must not be null or none !";
        console.log(err_msg);
        res.render('shop/edit',{err_msg:err_msg});
    }else{
        
    var shop = new model({
        name:req.body.name,
        address:req.body.address,
        latitude:req.body.latitude,
        longitude:req.body.longitude,
        description:req.body.description,
        mobile:req.body.mobile,
        createdAt:moment().format("YYYY-MM-DD hh:mm:ss"),
        modifiedAt:moment().format("YYYY-MM-DD hh:mm:ss")
        });
        shop.save(function(err,doc){
            // console.log(doc);
            res.redirect('/shops/')
        });
    }
});

var validate = function(dic){
    console.log(dic);
    for (var key in dic){
        var val = dic[key];
        console.log(val);
        if(val.length ==0){
            return false;
        }
    }
    return true;
};








module.exports = router;

