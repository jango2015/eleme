/**
 * 
 * created by jango cheng 2016/11/01
 * 
 */
var dbprovider = require("./../db/mongodbclient.js");
var shopSchema = dbprovider.Schema;
var shopmodelSchema = new shopSchema({
    name:String,
    address:String,
    latitude:String,
    longitude:String,
    description:String,
    mobile:String,
    createdAt:Date,
    modifiedAt:Date
});

exports.shopmodel = dbprovider.db.model('shops',shopmodelSchema);
