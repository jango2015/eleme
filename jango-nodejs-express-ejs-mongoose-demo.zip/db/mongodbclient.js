/**
 * 
 * created by jango cheng 2016/11/01
 * 
 */
var mongoose = require('mongoose');
var db = mongoose.connect("mongodb://localhost/Jbooking");
exports.Schema = mongoose.Schema;
exports.db =db;